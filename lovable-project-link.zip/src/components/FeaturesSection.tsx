import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Brain,
  Users,
  BarChart3,
  Workflow,
  Shield,
} from "lucide-react";

const features = [
  {
    icon: LayoutDashboard,
    title: "Intuitive Board View",
    description:
      "Drag-and-drop Kanban boards that adapt to your workflow. Customize columns, labels, and priorities to match how your team works.",
    gradient: "from-primary-500 to-primary-700",
    bg: "bg-primary-50",
  },
  {
    icon: Brain,
    title: "AI-Powered Insights",
    description:
      "Smart suggestions for task assignment, sprint planning, and bottleneck detection. Let AI handle the analysis while you focus on building.",
    gradient: "from-accent-500 to-accent-700",
    bg: "bg-accent-50",
  },
  {
    icon: Users,
    title: "Real-time Collaboration",
    description:
      "See who's working on what in real-time. @mention teammates, leave comments, and share updates without leaving the board.",
    gradient: "from-success-500 to-success-600",
    bg: "bg-success-50",
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description:
      "Track velocity, burndown charts, and team performance with beautiful, actionable dashboards that update in real-time.",
    gradient: "from-warning-500 to-warning-600",
    bg: "bg-warning-50",
  },
  {
    icon: Workflow,
    title: "Automation Engine",
    description:
      "Create powerful automations without code. Auto-assign tasks, send notifications, and update statuses based on custom triggers.",
    gradient: "from-primary-600 to-accent-500",
    bg: "bg-primary-50",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description:
      "SOC 2 compliant with SSO, role-based access, and audit logs. Your data is encrypted at rest and in transit.",
    gradient: "from-surface-600 to-surface-800",
    bg: "bg-surface-50",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-primary-600">
            Features
          </span>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-surface-900 sm:text-4xl">
            Everything you need to ship faster
          </h2>
          <p className="mt-4 text-lg text-surface-500">
            Powerful features designed for modern teams. From planning to delivery, FlowBoard has you covered.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="group relative rounded-2xl border border-surface-100 bg-white p-7 transition-all hover:border-primary-200 hover:shadow-xl hover:shadow-primary-100/50"
            >
              <div
                className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${feature.gradient} shadow-lg`}
              >
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-surface-900">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-surface-500">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
