import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Play, CheckCircle2 } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden pt-28 pb-20 lg:pt-36 lg:pb-32">
      {/* Background decorations */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1200px] h-[600px] bg-gradient-to-b from-primary-100/60 via-accent-50/30 to-transparent rounded-full blur-3xl" />
        <div className="absolute top-40 right-0 w-72 h-72 bg-accent-200/30 rounded-full blur-3xl animate-float" />
        <div className="absolute top-60 left-0 w-96 h-96 bg-primary-200/20 rounded-full blur-3xl animate-float-delayed" />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-4 py-1.5 text-sm font-medium text-primary-700 ring-1 ring-primary-200">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary-500" />
              </span>
              Now in Public Beta — Free to try
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mt-8 text-4xl font-extrabold tracking-tight text-surface-900 sm:text-5xl lg:text-6xl"
          >
            Manage projects with{" "}
            <span className="gradient-text">clarity & flow</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-surface-500"
          >
            FlowBoard brings your team's work together in one beautiful space. Plan sprints,
            track progress, and ship faster with AI-powered insights that keep everyone aligned.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center"
          >
            <Link
              to="/dashboard"
              className="group flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary-600 to-primary-700 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-primary-200 transition-all hover:shadow-xl hover:shadow-primary-300 hover:scale-[1.02]"
            >
              Get Started Free
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <button className="group flex items-center gap-2 rounded-xl bg-white px-7 py-3.5 text-sm font-semibold text-surface-700 shadow-md ring-1 ring-surface-200 transition-all hover:shadow-lg hover:scale-[1.02]">
              <Play className="h-4 w-4 text-primary-500" />
              Watch Demo
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-surface-500"
          >
            {["No credit card required", "14-day free trial", "Cancel anytime"].map((item) => (
              <span key={item} className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-success-500" />
                {item}
              </span>
            ))}
          </motion.div>
        </div>

        {/* Hero Image / Dashboard Preview */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="relative mx-auto mt-16 max-w-5xl"
        >
          <div className="absolute -inset-4 rounded-2xl bg-gradient-to-r from-primary-400/20 via-accent-400/20 to-primary-400/20 blur-2xl" />
          <div className="relative overflow-hidden rounded-2xl border border-surface-200 bg-white shadow-2xl shadow-surface-200/50">
            <div className="flex items-center gap-1.5 border-b border-surface-100 bg-surface-50 px-4 py-3">
              <div className="h-3 w-3 rounded-full bg-danger-500/80" />
              <div className="h-3 w-3 rounded-full bg-warning-500/80" />
              <div className="h-3 w-3 rounded-full bg-success-500/80" />
              <span className="ml-3 text-xs text-surface-400">flowboard.app/dashboard</span>
            </div>
            <DashboardPreview />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function DashboardPreview() {
  const tasks = [
    { name: "Design system update", status: "In Progress", priority: "High", color: "bg-warning-500" },
    { name: "API integration", status: "Review", priority: "Medium", color: "bg-primary-500" },
    { name: "User onboarding flow", status: "Done", priority: "High", color: "bg-success-500" },
    { name: "Analytics dashboard", status: "To Do", priority: "Low", color: "bg-surface-400" },
  ];

  return (
    <div className="grid grid-cols-12 gap-0">
      {/* Sidebar */}
      <div className="col-span-3 hidden border-r border-surface-100 bg-surface-50/50 p-4 lg:block">
        <div className="space-y-1">
          {["Dashboard", "My Tasks", "Projects", "Team", "Calendar", "Reports"].map((item, i) => (
            <div
              key={item}
              className={`rounded-lg px-3 py-2 text-xs font-medium ${
                i === 0 ? "bg-primary-50 text-primary-700" : "text-surface-500"
              }`}
            >
              {item}
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div className="col-span-12 p-4 sm:p-6 lg:col-span-9">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-surface-800">Sprint 24 — Week Overview</h3>
            <p className="text-xs text-surface-400 mt-0.5">12 tasks · 4 completed</p>
          </div>
          <div className="flex gap-2">
            <div className="rounded-lg bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-600">Board</div>
            <div className="rounded-lg px-3 py-1.5 text-xs font-medium text-surface-400">List</div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-5 h-2 w-full overflow-hidden rounded-full bg-surface-100">
          <div className="h-full w-[33%] rounded-full bg-gradient-to-r from-primary-500 to-accent-500" />
        </div>

        {/* Tasks */}
        <div className="space-y-2">
          {tasks.map((task) => (
            <div
              key={task.name}
              className="flex items-center justify-between rounded-xl border border-surface-100 p-3 transition hover:border-primary-200 hover:bg-primary-50/30"
            >
              <div className="flex items-center gap-3">
                <div className={`h-2.5 w-2.5 rounded-full ${task.color}`} />
                <span className="text-xs font-medium text-surface-700">{task.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-surface-100 px-2.5 py-0.5 text-[10px] font-medium text-surface-500">
                  {task.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
