import {
  LayoutDashboard,
  CheckSquare,
  FolderKanban,
  Users,
  Calendar,
  BarChart3,
  Settings,
  HelpCircle,
  Zap,
  ChevronDown,
  Plus,
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  collapsed?: boolean;
}

const mainNav = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "tasks", label: "My Tasks", icon: CheckSquare },
  { id: "projects", label: "Projects", icon: FolderKanban },
  { id: "team", label: "Team", icon: Users },
  { id: "calendar", label: "Calendar", icon: Calendar },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
];

const projects = [
  { name: "Website Redesign", color: "bg-primary-500" },
  { name: "Mobile App v2", color: "bg-accent-500" },
  { name: "API Integration", color: "bg-success-500" },
  { name: "Design System", color: "bg-warning-500" },
];

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <aside className="flex h-full w-64 flex-col border-r border-surface-100 bg-white">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2.5 border-b border-surface-100 px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-accent-500">
          <Zap className="h-4 w-4 text-white" />
        </div>
        <span className="text-base font-bold text-surface-900">FlowBoard</span>
      </div>

      {/* Workspace selector */}
      <div className="border-b border-surface-100 px-4 py-3">
        <button className="flex w-full items-center justify-between rounded-lg bg-surface-50 px-3 py-2 text-sm transition hover:bg-surface-100">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded bg-gradient-to-br from-primary-500 to-primary-600 text-[10px] font-bold text-white">
              A
            </div>
            <span className="font-medium text-surface-700">Acme Inc.</span>
          </div>
          <ChevronDown className="h-4 w-4 text-surface-400" />
        </button>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 overflow-y-auto px-3 py-4">
        <nav className="space-y-1">
          {mainNav.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${
                activeTab === item.id
                  ? "bg-primary-50 text-primary-700"
                  : "text-surface-600 hover:bg-surface-50 hover:text-surface-800"
              }`}
            >
              <item.icon className="h-4.5 w-4.5" />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Projects */}
        <div className="mt-8">
          <div className="flex items-center justify-between px-3 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-surface-400">
              Projects
            </span>
            <button className="rounded p-0.5 text-surface-400 transition hover:text-primary-600 hover:bg-surface-100">
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="space-y-0.5">
            {projects.map((project) => (
              <button
                key={project.name}
                className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-surface-600 transition hover:bg-surface-50 hover:text-surface-800"
              >
                <div className={`h-2.5 w-2.5 rounded-full ${project.color}`} />
                <span className="truncate">{project.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom */}
      <div className="border-t border-surface-100 px-3 py-3">
        <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-surface-600 transition hover:bg-surface-50">
          <Settings className="h-4 w-4" />
          Settings
        </button>
        <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-surface-600 transition hover:bg-surface-50">
          <HelpCircle className="h-4 w-4" />
          Help & Support
        </button>
      </div>
    </aside>
  );
}
