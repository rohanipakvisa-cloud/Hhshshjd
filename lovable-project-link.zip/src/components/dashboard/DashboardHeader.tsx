import { Bell, Search, Menu } from "lucide-react";

interface DashboardHeaderProps {
  onMenuClick: () => void;
}

export default function DashboardHeader({ onMenuClick }: DashboardHeaderProps) {
  return (
    <header className="flex h-16 items-center justify-between border-b border-surface-100 bg-white px-4 sm:px-6">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="rounded-lg p-2 text-surface-500 transition hover:bg-surface-100 lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-surface-400" />
          <input
            type="text"
            placeholder="Search tasks, projects..."
            className="w-64 rounded-lg border border-surface-200 bg-surface-50 py-2 pl-10 pr-4 text-sm text-surface-700 placeholder-surface-400 transition focus:border-primary-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-100 sm:w-80"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button className="relative rounded-lg p-2 text-surface-500 transition hover:bg-surface-100">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-danger-500 ring-2 ring-white" />
        </button>

        <div className="h-6 w-px bg-surface-200" />

        <button className="flex items-center gap-2.5 rounded-lg p-1.5 transition hover:bg-surface-100">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-accent-500 text-xs font-bold text-white">
            JD
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-medium text-surface-700">Jane Doe</p>
            <p className="text-xs text-surface-400">jane@acme.com</p>
          </div>
        </button>
      </div>
    </header>
  );
}
