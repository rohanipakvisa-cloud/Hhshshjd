import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

const velocityData = [
  { name: "Sprint 18", tasks: 28 },
  { name: "Sprint 19", tasks: 35 },
  { name: "Sprint 20", tasks: 31 },
  { name: "Sprint 21", tasks: 42 },
  { name: "Sprint 22", tasks: 38 },
  { name: "Sprint 23", tasks: 45 },
  { name: "Sprint 24", tasks: 33 },
];

const teamData = [
  { name: "Sarah", completed: 12, inProgress: 3 },
  { name: "Marcus", completed: 9, inProgress: 5 },
  { name: "Elena", completed: 15, inProgress: 2 },
  { name: "David", completed: 8, inProgress: 4 },
  { name: "Amara", completed: 11, inProgress: 3 },
];

export default function ChartSection() {
  return (
    <div className="mt-6 grid gap-6 lg:grid-cols-2">
      {/* Velocity Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-xl border border-surface-100 bg-white p-5 shadow-sm"
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-surface-800">Sprint Velocity</h3>
            <p className="text-xs text-surface-400 mt-0.5">Tasks completed per sprint</p>
          </div>
          <select className="rounded-lg border border-surface-200 bg-surface-50 px-3 py-1.5 text-xs text-surface-600 outline-none focus:border-primary-300">
            <option>Last 7 sprints</option>
            <option>Last 14 sprints</option>
          </select>
        </div>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={velocityData}>
              <defs>
                <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4263eb" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#4263eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e9ecf5" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#7c849b" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#7c849b" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  background: "white",
                  border: "1px solid #e9ecf5",
                  borderRadius: "8px",
                  fontSize: "12px",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                }}
              />
              <Area
                type="monotone"
                dataKey="tasks"
                stroke="#4263eb"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#colorTasks)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Team Performance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="rounded-xl border border-surface-100 bg-white p-5 shadow-sm"
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-surface-800">Team Performance</h3>
            <p className="text-xs text-surface-400 mt-0.5">Current sprint breakdown</p>
          </div>
          <select className="rounded-lg border border-surface-200 bg-surface-50 px-3 py-1.5 text-xs text-surface-600 outline-none focus:border-primary-300">
            <option>This Sprint</option>
            <option>Last Sprint</option>
          </select>
        </div>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={teamData} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e9ecf5" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#7c849b" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#7c849b" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  background: "white",
                  border: "1px solid #e9ecf5",
                  borderRadius: "8px",
                  fontSize: "12px",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                }}
              />
              <Bar dataKey="completed" fill="#4263eb" radius={[4, 4, 0, 0]} />
              <Bar dataKey="inProgress" fill="#f06595" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-3 flex items-center justify-center gap-6">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-sm bg-primary-600" />
            <span className="text-xs text-surface-500">Completed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-sm bg-accent-500" />
            <span className="text-xs text-surface-500">In Progress</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
