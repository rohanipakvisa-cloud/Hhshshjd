import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, MoreHorizontal, MessageSquare, Paperclip, Calendar as CalIcon } from "lucide-react";

interface Task {
  id: string;
  title: string;
  description?: string;
  priority: "low" | "medium" | "high" | "urgent";
  assignee: { initials: string; color: string };
  comments: number;
  attachments: number;
  dueDate?: string;
  tags: { label: string; color: string }[];
}

interface Column {
  id: string;
  title: string;
  color: string;
  tasks: Task[];
}

const initialColumns: Column[] = [
  {
    id: "todo",
    title: "To Do",
    color: "bg-surface-400",
    tasks: [
      {
        id: "1",
        title: "Design new onboarding flow",
        description: "Create wireframes and user journey maps",
        priority: "high",
        assignee: { initials: "SC", color: "from-primary-400 to-primary-600" },
        comments: 3,
        attachments: 2,
        dueDate: "Dec 15",
        tags: [{ label: "Design", color: "bg-purple-100 text-purple-700" }],
      },
      {
        id: "2",
        title: "Update API documentation",
        priority: "medium",
        assignee: { initials: "MJ", color: "from-accent-400 to-accent-600" },
        comments: 1,
        attachments: 0,
        dueDate: "Dec 18",
        tags: [{ label: "Docs", color: "bg-blue-100 text-blue-700" }],
      },
      {
        id: "3",
        title: "Set up monitoring alerts",
        priority: "low",
        assignee: { initials: "DP", color: "from-warning-500 to-warning-600" },
        comments: 0,
        attachments: 1,
        tags: [{ label: "DevOps", color: "bg-orange-100 text-orange-700" }],
      },
    ],
  },
  {
    id: "in-progress",
    title: "In Progress",
    color: "bg-primary-500",
    tasks: [
      {
        id: "4",
        title: "Implement user authentication",
        description: "OAuth2 + JWT implementation",
        priority: "urgent",
        assignee: { initials: "ER", color: "from-success-500 to-success-600" },
        comments: 8,
        attachments: 3,
        dueDate: "Dec 12",
        tags: [
          { label: "Backend", color: "bg-green-100 text-green-700" },
          { label: "Security", color: "bg-red-100 text-red-700" },
        ],
      },
      {
        id: "5",
        title: "Dashboard analytics charts",
        priority: "high",
        assignee: { initials: "JW", color: "from-surface-600 to-surface-800" },
        comments: 5,
        attachments: 1,
        dueDate: "Dec 14",
        tags: [{ label: "Frontend", color: "bg-cyan-100 text-cyan-700" }],
      },
    ],
  },
  {
    id: "review",
    title: "In Review",
    color: "bg-warning-500",
    tasks: [
      {
        id: "6",
        title: "Payment integration tests",
        priority: "high",
        assignee: { initials: "AO", color: "from-primary-600 to-accent-500" },
        comments: 4,
        attachments: 2,
        dueDate: "Dec 11",
        tags: [
          { label: "Testing", color: "bg-yellow-100 text-yellow-700" },
          { label: "Payments", color: "bg-emerald-100 text-emerald-700" },
        ],
      },
    ],
  },
  {
    id: "done",
    title: "Done",
    color: "bg-success-500",
    tasks: [
      {
        id: "7",
        title: "Setup CI/CD pipeline",
        priority: "medium",
        assignee: { initials: "DP", color: "from-warning-500 to-warning-600" },
        comments: 2,
        attachments: 0,
        tags: [{ label: "DevOps", color: "bg-orange-100 text-orange-700" }],
      },
      {
        id: "8",
        title: "Database schema migration",
        priority: "high",
        assignee: { initials: "MJ", color: "from-accent-400 to-accent-600" },
        comments: 6,
        attachments: 1,
        tags: [{ label: "Backend", color: "bg-green-100 text-green-700" }],
      },
    ],
  },
];

const priorityColors = {
  low: "bg-surface-200 text-surface-600",
  medium: "bg-primary-100 text-primary-700",
  high: "bg-warning-100 text-warning-700",
  urgent: "bg-danger-100 text-danger-700",
};

export default function TaskBoard() {
  const [columns] = useState(initialColumns);

  return (
    <div className="mt-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-surface-900">Sprint Board</h2>
        <button className="flex items-center gap-2 rounded-lg bg-primary-600 px-3.5 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-primary-700">
          <Plus className="h-4 w-4" />
          Add Task
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4">
        {columns.map((column, colIndex) => (
          <motion.div
            key={column.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: colIndex * 0.1 }}
            className="flex w-72 shrink-0 flex-col rounded-xl bg-surface-50 p-3"
          >
            {/* Column header */}
            <div className="mb-3 flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <div className={`h-2.5 w-2.5 rounded-full ${column.color}`} />
                <span className="text-sm font-semibold text-surface-700">{column.title}</span>
                <span className="rounded-full bg-surface-200 px-2 py-0.5 text-xs font-medium text-surface-500">
                  {column.tasks.length}
                </span>
              </div>
              <button className="rounded p-1 text-surface-400 hover:bg-surface-200 hover:text-surface-600">
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </div>

            {/* Tasks */}
            <div className="space-y-2.5">
              {column.tasks.map((task) => (
                <motion.div
                  key={task.id}
                  whileHover={{ scale: 1.02 }}
                  className="cursor-pointer rounded-lg border border-surface-100 bg-white p-3 shadow-sm transition hover:shadow-md"
                >
                  {/* Tags */}
                  <div className="mb-2 flex flex-wrap gap-1.5">
                    {task.tags.map((tag) => (
                      <span
                        key={tag.label}
                        className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${tag.color}`}
                      >
                        {tag.label}
                      </span>
                    ))}
                  </div>

                  {/* Title */}
                  <h4 className="text-sm font-medium text-surface-800">{task.title}</h4>
                  {task.description && (
                    <p className="mt-1 text-xs text-surface-400 line-clamp-2">{task.description}</p>
                  )}

                  {/* Footer */}
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {task.dueDate && (
                        <span className="flex items-center gap-1 text-xs text-surface-400">
                          <CalIcon className="h-3 w-3" />
                          {task.dueDate}
                        </span>
                      )}
                      {task.comments > 0 && (
                        <span className="flex items-center gap-1 text-xs text-surface-400">
                          <MessageSquare className="h-3 w-3" />
                          {task.comments}
                        </span>
                      )}
                      {task.attachments > 0 && (
                        <span className="flex items-center gap-1 text-xs text-surface-400">
                          <Paperclip className="h-3 w-3" />
                          {task.attachments}
                        </span>
                      )}
                    </div>
                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br ${task.assignee.color} text-[9px] font-bold text-white`}
                    >
                      {task.assignee.initials}
                    </div>
                  </div>

                  {/* Priority badge */}
                  <div className="mt-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${priorityColors[task.priority]}`}
                    >
                      {task.priority}
                    </span>
                  </div>
                </motion.div>
              ))}

              {/* Add task button */}
              <button className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-surface-200 py-2 text-xs text-surface-400 transition hover:border-primary-300 hover:text-primary-600 hover:bg-primary-50/50">
                <Plus className="h-3.5 w-3.5" />
                Add task
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
