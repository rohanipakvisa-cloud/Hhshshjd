import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, CheckCircle2, Clock, AlertCircle, Users } from "lucide-react";

const stats = [
  {
    title: "Total Tasks",
    value: "248",
    change: "+12%",
    trending: "up" as const,
    icon: CheckCircle2,
    gradient: "from-primary-500 to-primary-600",
    bgColor: "bg-primary-50",
  },
  {
    title: "In Progress",
    value: "42",
    change: "+5%",
    trending: "up" as const,
    icon: Clock,
    gradient: "from-warning-500 to-warning-600",
    bgColor: "bg-warning-50",
  },
  {
    title: "Overdue",
    value: "7",
    change: "-23%",
    trending: "down" as const,
    icon: AlertCircle,
    gradient: "from-danger-500 to-danger-600",
    bgColor: "bg-danger-50",
  },
  {
    title: "Team Members",
    value: "16",
    change: "+2",
    trending: "up" as const,
    icon: Users,
    gradient: "from-success-500 to-success-600",
    bgColor: "bg-success-50",
  },
];

export default function StatsCards() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="rounded-xl border border-surface-100 bg-white p-5 shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br ${stat.gradient}`}
            >
              <stat.icon className="h-5 w-5 text-white" />
            </div>
            <div
              className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                stat.trending === "up"
                  ? "bg-success-50 text-success-600"
                  : "bg-danger-50 text-danger-600"
              }`}
            >
              {stat.trending === "up" ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              {stat.change}
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-bold text-surface-900">{stat.value}</p>
            <p className="text-sm text-surface-500">{stat.title}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
