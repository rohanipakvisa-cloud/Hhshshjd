import { motion } from "framer-motion";
import { CheckCircle2, MessageSquare, GitBranch, UserPlus, AlertTriangle } from "lucide-react";

const activities = [
  {
    id: 1,
    user: { initials: "SC", color: "from-primary-400 to-primary-600" },
    action: "completed",
    target: "Design system component library",
    time: "2 min ago",
    icon: CheckCircle2,
    iconColor: "text-success-500",
    iconBg: "bg-success-50",
  },
  {
    id: 2,
    user: { initials: "MJ", color: "from-accent-400 to-accent-600" },
    action: "commented on",
    target: "API endpoint restructuring",
    time: "15 min ago",
    icon: MessageSquare,
    iconColor: "text-primary-500",
    iconBg: "bg-primary-50",
  },
  {
    id: 3,
    user: { initials: "ER", color: "from-success-500 to-success-600" },
    action: "pushed to",
    target: "feature/auth-flow branch",
    time: "32 min ago",
    icon: GitBranch,
    iconColor: "text-accent-500",
    iconBg: "bg-accent-50",
  },
  {
    id: 4,
    user: { initials: "JD", color: "from-primary-500 to-accent-500" },
    action: "added",
    target: "Alex Kim to the team",
    time: "1 hour ago",
    icon: UserPlus,
    iconColor: "text-primary-600",
    iconBg: "bg-primary-50",
  },
  {
    id: 5,
    user: { initials: "DP", color: "from-warning-500 to-warning-600" },
    action: "flagged",
    target: "Performance regression in build #847",
    time: "2 hours ago",
    icon: AlertTriangle,
    iconColor: "text-warning-500",
    iconBg: "bg-warning-50",
  },
];

export default function RecentActivity() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="mt-6 rounded-xl border border-surface-100 bg-white p-5 shadow-sm"
    >
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-surface-800">Recent Activity</h3>
        <button className="text-xs font-medium text-primary-600 transition hover:text-primary-700">
          View All
        </button>
      </div>

      <div className="space-y-4">
        {activities.map((activity, index) => (
          <motion.div
            key={activity.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 + index * 0.08 }}
            className="flex items-start gap-3"
          >
            <div
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${activity.iconBg}`}
            >
              <activity.icon className={`h-4 w-4 ${activity.iconColor}`} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm text-surface-600">
                <span className="font-medium text-surface-800">{activity.user.initials}</span>{" "}
                {activity.action}{" "}
                <span className="font-medium text-surface-800">{activity.target}</span>
              </p>
              <p className="mt-0.5 text-xs text-surface-400">{activity.time}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
