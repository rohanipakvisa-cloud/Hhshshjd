import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X, Zap } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-accent-500 shadow-md shadow-primary-200">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-bold text-surface-900">FlowBoard</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden items-center gap-8 md:flex">
            <a href="#features" className="text-sm font-medium text-surface-600 transition hover:text-primary-600">
              Features
            </a>
            <a href="#how-it-works" className="text-sm font-medium text-surface-600 transition hover:text-primary-600">
              How It Works
            </a>
            <a href="#pricing" className="text-sm font-medium text-surface-600 transition hover:text-primary-600">
              Pricing
            </a>
            <a href="#testimonials" className="text-sm font-medium text-surface-600 transition hover:text-primary-600">
              Testimonials
            </a>
          </div>

          <div className="hidden items-center gap-3 md:flex">
            <Link
              to="/dashboard"
              className="rounded-lg px-4 py-2 text-sm font-medium text-surface-700 transition hover:bg-surface-100"
            >
              Log in
            </Link>
            <Link
              to="/dashboard"
              className="rounded-lg bg-gradient-to-r from-primary-600 to-primary-700 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-primary-200 transition hover:shadow-lg hover:shadow-primary-300"
            >
              Start Free Trial
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="inline-flex items-center justify-center rounded-lg p-2 text-surface-600 transition hover:bg-surface-100 md:hidden"
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden border-t border-surface-200 md:hidden"
          >
            <div className="space-y-1 px-4 py-4">
              <a href="#features" className="block rounded-lg px-3 py-2 text-sm font-medium text-surface-600 hover:bg-surface-100">
                Features
              </a>
              <a href="#how-it-works" className="block rounded-lg px-3 py-2 text-sm font-medium text-surface-600 hover:bg-surface-100">
                How It Works
              </a>
              <a href="#pricing" className="block rounded-lg px-3 py-2 text-sm font-medium text-surface-600 hover:bg-surface-100">
                Pricing
              </a>
              <a href="#testimonials" className="block rounded-lg px-3 py-2 text-sm font-medium text-surface-600 hover:bg-surface-100">
                Testimonials
              </a>
              <div className="pt-2">
                <Link
                  to="/dashboard"
                  className="block w-full rounded-lg bg-gradient-to-r from-primary-600 to-primary-700 px-4 py-2.5 text-center text-sm font-semibold text-white shadow-md"
                >
                  Start Free Trial
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
