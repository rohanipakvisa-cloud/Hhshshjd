import { motion } from "framer-motion";
import { Check, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

const plans = [
  {
    name: "Starter",
    description: "Perfect for small teams just getting started",
    price: "0",
    period: "forever",
    cta: "Get Started Free",
    features: [
      "Up to 5 team members",
      "3 projects",
      "Basic Kanban boards",
      "Task management",
      "1GB storage",
      "Community support",
    ],
    popular: false,
  },
  {
    name: "Pro",
    description: "For growing teams that need more power",
    price: "12",
    period: "per user / month",
    cta: "Start Free Trial",
    features: [
      "Unlimited team members",
      "Unlimited projects",
      "Advanced boards & timelines",
      "AI-powered insights",
      "Automation engine",
      "20GB storage",
      "Priority support",
      "Custom fields & views",
    ],
    popular: true,
  },
  {
    name: "Enterprise",
    description: "For organizations with advanced needs",
    price: "39",
    period: "per user / month",
    cta: "Contact Sales",
    features: [
      "Everything in Pro",
      "SSO & SAML",
      "Advanced security & compliance",
      "Custom integrations",
      "Unlimited storage",
      "Dedicated account manager",
      "SLA guarantees",
      "On-premise deployment",
    ],
    popular: false,
  },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="relative py-24 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-primary-600">
            Pricing
          </span>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-surface-900 sm:text-4xl">
            Simple, transparent pricing
          </h2>
          <p className="mt-4 text-lg text-surface-500">
            Start free, scale as you grow. No hidden fees, no surprises.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative rounded-2xl border p-8 transition-all ${
                plan.popular
                  ? "border-primary-300 bg-gradient-to-b from-primary-50/50 to-white shadow-xl shadow-primary-100/50 scale-105"
                  : "border-surface-200 bg-white hover:border-primary-200 hover:shadow-lg"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-primary-600 to-accent-500 px-4 py-1 text-xs font-semibold text-white shadow-lg">
                    <Sparkles className="h-3 w-3" />
                    Most Popular
                  </span>
                </div>
              )}

              <div>
                <h3 className="text-lg font-bold text-surface-900">{plan.name}</h3>
                <p className="mt-1 text-sm text-surface-500">{plan.description}</p>
              </div>

              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-surface-900">${plan.price}</span>
                <span className="text-sm text-surface-400">/ {plan.period}</span>
              </div>

              <Link
                to="/dashboard"
                className={`mt-8 block w-full rounded-xl py-3 text-center text-sm font-semibold transition-all ${
                  plan.popular
                    ? "bg-gradient-to-r from-primary-600 to-primary-700 text-white shadow-lg shadow-primary-200 hover:shadow-xl"
                    : "bg-surface-900 text-white hover:bg-surface-800"
                }`}
              >
                {plan.cta}
              </Link>

              <ul className="mt-8 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                    <span className="text-sm text-surface-600">{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
