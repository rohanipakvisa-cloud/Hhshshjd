import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Engineering Lead at Stripe",
    avatar: "SC",
    color: "from-primary-400 to-primary-600",
    content:
      "FlowBoard transformed how our team ships. The AI insights caught bottlenecks we'd have missed, and sprint planning went from 2 hours to 20 minutes.",
    rating: 5,
  },
  {
    name: "Marcus Johnson",
    role: "CTO at Vercel",
    avatar: "MJ",
    color: "from-accent-400 to-accent-600",
    content:
      "We tried every PM tool out there. FlowBoard is the only one our engineers actually enjoy using. The interface is beautiful and fast.",
    rating: 5,
  },
  {
    name: "Elena Rodriguez",
    role: "Product Manager at Figma",
    avatar: "ER",
    color: "from-success-500 to-success-600",
    content:
      "The automation engine alone saves our team 10+ hours per week. Setting up workflows is intuitive and the templates are fantastic.",
    rating: 5,
  },
  {
    name: "David Park",
    role: "Founder at Raycast",
    avatar: "DP",
    color: "from-warning-500 to-warning-600",
    content:
      "Clean, fast, and thoughtfully designed. FlowBoard feels like it was built by people who actually manage projects, not just build tools.",
    rating: 5,
  },
  {
    name: "Amara Obi",
    role: "VP Engineering at Linear",
    avatar: "AO",
    color: "from-primary-600 to-accent-500",
    content:
      "The real-time collaboration is seamless. Our distributed team across 4 timezones stays perfectly in sync. Best investment we've made.",
    rating: 5,
  },
  {
    name: "James Wright",
    role: "Tech Lead at Notion",
    avatar: "JW",
    color: "from-surface-600 to-surface-800",
    content:
      "FlowBoard's analytics give us visibility we never had before. We can now predict sprint outcomes with surprising accuracy.",
    rating: 5,
  },
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="relative py-24 bg-surface-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-primary-600">
            Testimonials
          </span>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-surface-900 sm:text-4xl">
            Loved by teams worldwide
          </h2>
          <p className="mt-4 text-lg text-surface-500">
            Join 10,000+ teams already shipping faster with FlowBoard.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="rounded-2xl border border-surface-100 bg-white p-6 shadow-sm transition hover:shadow-md"
            >
              <div className="flex gap-1">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="h-4 w-4 fill-warning-500 text-warning-500"
                  />
                ))}
              </div>
              <p className="mt-4 text-sm leading-relaxed text-surface-600">
                "{testimonial.content}"
              </p>
              <div className="mt-5 flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br ${testimonial.color} text-xs font-bold text-white`}
                >
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="text-sm font-semibold text-surface-900">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-surface-400">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
