import { Zap } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-surface-100 bg-surface-50 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-accent-500 shadow-md">
                <Zap className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-bold text-surface-900">FlowBoard</span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-surface-500">
              Smart project management for modern teams. Plan, track, and ship with clarity.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-surface-900">Product</h4>
            <ul className="mt-4 space-y-2.5">
              {["Features", "Pricing", "Integrations", "Changelog", "Roadmap"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-surface-500 transition hover:text-primary-600">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-surface-900">Company</h4>
            <ul className="mt-4 space-y-2.5">
              {["About", "Blog", "Careers", "Press", "Contact"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-surface-500 transition hover:text-primary-600">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-surface-900">Resources</h4>
            <ul className="mt-4 space-y-2.5">
              {["Documentation", "API Reference", "Community", "Support", "Status"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-surface-500 transition hover:text-primary-600">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-surface-200 pt-8 sm:flex-row">
          <p className="text-sm text-surface-400">
            © 2025 FlowBoard. All rights reserved.
          </p>
          <div className="flex gap-6">
            {["Privacy", "Terms", "Cookies"].map((item) => (
              <a key={item} href="#" className="text-sm text-surface-400 transition hover:text-surface-600">
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
