import { motion } from "framer-motion";
import { FolderPlus, ListChecks, Rocket } from "lucide-react";

const steps = [
  {
    step: "01",
    icon: FolderPlus,
    title: "Create Your Project",
    description:
      "Set up your workspace in seconds. Import from existing tools or start fresh with customizable templates.",
    gradient: "from-primary-500 to-primary-600",
  },
  {
    step: "02",
    icon: ListChecks,
    title: "Plan & Collaborate",
    description:
      "Break down work into tasks, assign teammates, and plan sprints with AI-powered estimations.",
    gradient: "from-accent-500 to-accent-600",
  },
  {
    step: "03",
    icon: Rocket,
    title: "Ship & Iterate",
    description:
      "Track progress in real-time, gather insights from analytics, and continuously improve your workflow.",
    gradient: "from-success-500 to-success-600",
  },
];

export default function HowItWorksSection() {
  return (
    <section id="how-it-works" className="relative py-24 bg-surface-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-primary-600">
            How It Works
          </span>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-surface-900 sm:text-4xl">
            Up and running in minutes
          </h2>
          <p className="mt-4 text-lg text-surface-500">
            No complex setup. No steep learning curve. Just a clean, intuitive workflow.
          </p>
        </motion.div>

        <div className="relative mt-16">
          {/* Connector line */}
          <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-primary-200 via-accent-200 to-success-200 lg:block" />

          <div className="space-y-12 lg:space-y-0">
            {steps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className={`relative lg:grid lg:grid-cols-2 lg:gap-12 lg:py-12 ${
                  index % 2 === 1 ? "lg:direction-rtl" : ""
                }`}
              >
                {/* Step number on the line */}
                <div className="absolute left-1/2 top-1/2 z-10 hidden h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white shadow-lg ring-4 ring-white lg:flex">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br ${step.gradient} text-xs font-bold text-white`}
                  >
                    {step.step}
                  </div>
                </div>

                <div
                  className={`flex items-center ${
                    index % 2 === 1 ? "lg:col-start-2" : ""
                  }`}
                >
                  <div className="rounded-2xl border border-surface-100 bg-white p-8 shadow-md transition hover:shadow-lg w-full">
                    <div
                      className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${step.gradient} shadow-lg`}
                    >
                      <step.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="mt-5 text-xl font-bold text-surface-900">
                      {step.title}
                    </h3>
                    <p className="mt-3 text-surface-500 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>

                {index % 2 === 0 && <div className="hidden lg:block" />}
                {index % 2 === 1 && <div className="hidden lg:col-start-1 lg:row-start-1 lg:block" />}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
