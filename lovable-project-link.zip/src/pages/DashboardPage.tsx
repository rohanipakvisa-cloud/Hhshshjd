import { useState } from "react";
import Sidebar from "../components/dashboard/Sidebar";
import DashboardHeader from "../components/dashboard/DashboardHeader";
import StatsCards from "../components/dashboard/StatsCards";
import TaskBoard from "../components/dashboard/TaskBoard";
import ChartSection from "../components/dashboard/ChartSection";
import RecentActivity from "../components/dashboard/RecentActivity";
import { AnimatePresence, motion } from "framer-motion";

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-surface-50 overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/30"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 z-50"
            >
              <Sidebar activeTab={activeTab} onTabChange={(tab) => { setActiveTab(tab); setSidebarOpen(false); }} />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex flex-1 flex-col min-w-0">
        <DashboardHeader onMenuClick={() => setSidebarOpen(true)} />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* Welcome header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-surface-900">Good morning, Jane 👋</h1>
            <p className="mt-1 text-sm text-surface-500">
              Here's what's happening with your projects today.
            </p>
          </div>

          {/* Stats */}
          <StatsCards />

          {/* Charts */}
          <ChartSection />

          {/* Task Board */}
          <TaskBoard />

          {/* Recent Activity */}
          <RecentActivity />

          {/* Bottom spacing */}
          <div className="h-8" />
        </main>
      </div>
    </div>
  );
}
